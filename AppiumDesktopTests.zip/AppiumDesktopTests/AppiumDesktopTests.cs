using NUnit.Framework;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Windows;

namespace AppiumDesktopTests
{
    public class AppiumDesktopTests
    {
       private WindowsDriver<WindowsElement> driver;
       private AppiumOptions options;

        private const string appLocation = @"";
        private const string appiumServer = "";

        [SetUp]
        public void PrepareApp()
        {
            this.options= new AppiumOptions();
            options.AddAdditionalAppiumOption("app", appLocation);
            driver = new WindowsDriver<WindowsElement>(new Uri(appiumServer), options);
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
        }
        [TearDown]
        public void CloseApp() 
        { 
            driver.Quit();
        }

    }
}